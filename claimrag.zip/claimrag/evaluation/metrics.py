"""Evaluation metrics.

Four families, matching the four failure modes that actually matter here:
  decision quality, retrieval quality, citation correctness, abstention behaviour.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

STOP = {
    "the", "a", "an", "of", "and", "or", "to", "in", "for", "on", "is", "are", "be",
    "as", "by", "with", "that", "this", "it", "at", "from", "any", "such", "policy",
    "insured", "claim", "case", "will", "shall", "not", "under", "per", "has", "have",
}
TOKEN = re.compile(r"[a-z0-9]+")


def content_tokens(text: str) -> set[str]:
    return {t for t in TOKEN.findall(text.lower()) if t not in STOP and len(t) > 2}


# --------------------------------------------------------------------------- #
def evidence_recall(result: dict, anchors: list[list[str]], k: int | None = None) -> float | None:
    """Fraction of required policy anchors that appear in the retrieved evidence.

    Uses the evidence text actually shown to the agents, so it measures the
    retriever end-to-end (chunking + fusion + rerank), not embeddings alone.
    """
    if not anchors:
        return None
    texts = [e["text"].lower() for e in result.get("_evidence", [])][: k or None]
    blob = "\n".join(texts)
    hits = sum(1 for syns in anchors if any(s.lower() in blob for s in syns))
    return hits / len(anchors)


def citation_lexical_overlap(result: dict, threshold: float = 0.3) -> float | None:
    """Share of citations whose cited clause lexically covers the claim it supports.

    A cheap, LLM-free proxy for citation correctness: if a claim's content words
    barely appear in the clause cited for it, the citation is probably decorative.
    """
    ev = {e["chunk_id"]: e["text"].lower() for e in result.get("_evidence", [])}
    cites = result.get("citations", [])
    if not cites:
        return None
    good = 0
    for c in cites:
        claim = content_tokens(c["claim"])
        text = ev.get(c["chunk_id"], "")
        if not claim:
            continue
        covered = sum(1 for t in claim if t in text) / len(claim)
        good += covered >= threshold
    return good / len(cites)


def citation_support_rate(result: dict) -> float | None:
    """Validator-judged citation correctness: share of material claims the
    independent entailment check confirmed."""
    v = result.get("validation", {})
    n = v.get("checked_claims", 0)
    if not n:
        return None
    return max(0.0, (n - len(v.get("unsupported_claims", []))) / n)


def findings_citation_coverage(result: dict) -> float | None:
    """Share of material findings that carry at least one chunk_id."""
    mats = [f for f in result.get("key_findings", []) if f.get("material", True)]
    if not mats:
        return None
    return sum(1 for f in mats if f.get("chunk_ids")) / len(mats)


def leakage(result: dict, forbidden: list[str]) -> list[str]:
    """Irrelevant case attributes that leaked into decision text."""
    blob = " ".join(
        [f.get("statement", "") for f in result.get("key_findings", [])]
        + [c.get("claim", "") for c in result.get("citations", [])]
        + [result.get("next_action", "")]
    ).lower()
    return [w for w in forbidden if w.lower() in blob]


# --------------------------------------------------------------------------- #
@dataclass
class CaseScore:
    case_id: str
    labelled: bool
    decision: str
    expected: list[str] = field(default_factory=list)
    correct: bool | None = None
    expect_abstention: bool = False
    abstained: bool = False
    confidence: float = 0.0
    validation: str = ""
    n_citations: int = 0
    evidence_recall: float | None = None
    citation_overlap: float | None = None
    citation_support: float | None = None
    finding_coverage: float | None = None
    leaked: list[str] = field(default_factory=list)
    elapsed_ms: int = 0
    error: str | None = None

    def as_row(self) -> dict[str, Any]:
        def pct(x):
            return "—" if x is None else f"{x:.0%}"
        return {
            "case": self.case_id,
            "decision": self.decision,
            "expected": "/".join(self.expected) if self.expected else "—",
            "ok": "—" if self.correct is None else ("PASS" if self.correct else "FAIL"),
            "conf": f"{self.confidence:.2f}",
            "valid": self.validation,
            "cites": self.n_citations,
            "recall": pct(self.evidence_recall),
            "cite_ovl": pct(self.citation_overlap),
            "cite_sup": pct(self.citation_support),
            "ms": self.elapsed_ms,
        }


def score_case(result: dict, expectation: dict | None) -> CaseScore:
    decision = result.get("decision", "ERROR")
    sc = CaseScore(
        case_id=result.get("case_id", "?"),
        labelled=expectation is not None,
        decision=decision,
        abstained=bool(result.get("abstained")),
        confidence=float(result.get("confidence", 0.0)),
        validation=result.get("validation", {}).get("status", "—"),
        n_citations=len(result.get("citations", [])),
        citation_overlap=citation_lexical_overlap(result),
        citation_support=citation_support_rate(result),
        finding_coverage=findings_citation_coverage(result),
        elapsed_ms=int(result.get("elapsed_ms", 0)),
        error=result.get("_error"),
    )
    if expectation:
        sc.expected = expectation.get("expected_decision", [])
        sc.correct = decision in sc.expected
        sc.expect_abstention = bool(expectation.get("expect_abstention"))
        sc.evidence_recall = evidence_recall(result, expectation.get("evidence_anchors", []))
        sc.leaked = leakage(result, expectation.get("must_not_mention", []))
    return sc


def aggregate(scores: list[CaseScore]) -> dict[str, Any]:
    def mean(vals):
        vals = [v for v in vals if v is not None]
        return round(sum(vals) / len(vals), 4) if vals else None

    labelled = [s for s in scores if s.labelled]
    tp = sum(1 for s in labelled if s.expect_abstention and s.abstained)
    fn = sum(1 for s in labelled if s.expect_abstention and not s.abstained)
    fp = sum(1 for s in labelled if not s.expect_abstention and s.abstained)
    return {
        "cases_run": len(scores),
        "cases_labelled": len(labelled),
        "decision_accuracy": mean([1.0 if s.correct else 0.0 for s in labelled]),
        "evidence_recall_at_k": mean([s.evidence_recall for s in scores]),
        "citation_lexical_overlap": mean([s.citation_overlap for s in scores]),
        "citation_support_rate": mean([s.citation_support for s in scores]),
        "findings_citation_coverage": mean([s.finding_coverage for s in scores]),
        "validation_pass_rate": mean([1.0 if s.validation == "PASS" else 0.0 for s in scores]),
        "abstention": {
            "recall": round(tp / (tp + fn), 4) if (tp + fn) else None,
            "precision": round(tp / (tp + fp), 4) if (tp + fp) else None,
            "expected_abstentions": tp + fn,
            "over_abstentions": fp,
        },
        "attribute_leakage_cases": [s.case_id for s in scores if s.leaked],
        "mean_latency_ms": mean([float(s.elapsed_ms) for s in scores]),
        "errors": [s.case_id for s in scores if s.error],
    }
