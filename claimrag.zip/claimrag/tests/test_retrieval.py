from app.retrieval.fusion import reciprocal_rank_fusion
from app.retrieval.sparse import tokenize


def test_rrf_rewards_agreement():
    dense = [("a", 0.9), ("b", 0.8), ("c", 0.7)]
    sparse = [("c", 12.0), ("a", 9.0), ("d", 4.0)]
    fused = reciprocal_rank_fusion(dense, sparse, k=60)
    ids = [f.chunk_id for f in fused]
    # 'a' is top-1 dense and top-2 sparse -> must beat 'b' (dense only)
    assert ids.index("a") < ids.index("b")
    assert ids.index("c") < ids.index("d")
    a = next(f for f in fused if f.chunk_id == "a")
    assert a.dense_rank == 1 and a.sparse_rank == 2
    assert {"dense", "sparse"} == a.sources


def test_rrf_keeps_unique_hits():
    fused = reciprocal_rank_fusion([("x", 1.0)], [("y", 1.0)], k=60)
    assert {f.chunk_id for f in fused} == {"x", "y"}


def test_tokenizer_keeps_policy_terms():
    toks = tokenize("Pre-existing disease: 48 months of continuous coverage, sub-limit applies")
    assert "pre-existing" in toks
    assert "48" in toks
    assert "sub-limit" in toks
    assert "of" not in toks
