"""Behavioural tests for the agent workflow's safety invariants."""
from __future__ import annotations

import pytest

from app.agents.decision import DecisionAgent, DecisionDraft, DraftCitation
from app.graph import ClaimPipeline
from app.models import (
    ApplicableLimit,
    CaseState,
    ClaimCase,
    CoverageAssessment,
    Decision,
    EvidenceItem,
    Finding,
)


class ScriptedLLM:
    """Returns a queued object per schema name; records what it was asked."""

    def __init__(self, responses: dict):
        self.responses = responses
        self.calls = 0
        self.seen: list[str] = []
        self.ready = True

    def complete_json(self, system, user, schema):
        self.calls += 1
        self.seen.append(user)
        val = self.responses.get(schema.__name__)
        if val is None:
            return schema(), 1
        if callable(val):
            val = val(user)
        return schema.model_validate(val), 1


def state_with_evidence(chunks) -> CaseState:
    st = CaseState(case=ClaimCase(case_id="T-1"))
    st.evidence = [
        EvidenceItem(chunk_id=c.chunk_id, text=c.text, page=c.page, section=c.section,
                     rerank_score=1.0, final_rank=i + 1)
        for i, c in enumerate(chunks)
    ]
    return st


# --------------------------------------------------------------------------- #
def test_hallucinated_chunk_ids_are_stripped(chunks):
    st = state_with_evidence(chunks)
    agent = DecisionAgent(ScriptedLLM({}))
    draft = DecisionDraft(
        decision=Decision.ADMISSIBLE, confidence=0.95,
        key_findings=[Finding(dimension="scope", statement="Covered.",
                              verdict="SUPPORTS_COVERAGE", chunk_ids=["p007-scope-01-abc123", "MADE-UP-ID"])],
        citations=[DraftCitation(claim="Covered.", chunk_id="MADE-UP-ID"),
                   DraftCitation(claim="Covered.", chunk_id="p007-scope-01-abc123")],
    )
    agent._apply(st, draft)
    assert st.key_findings[0].chunk_ids == ["p007-scope-01-abc123"]
    assert [c.chunk_id for c in st.citations] == ["p007-scope-01-abc123"]
    assert st.citations[0].page == 7 and st.citations[0].section == "Scope of Cover"


def test_uncited_decision_is_forced_to_abstain(chunks):
    st = state_with_evidence(chunks)
    DecisionAgent(ScriptedLLM({}))._apply(
        st, DecisionDraft(decision=Decision.NOT_ADMISSIBLE, confidence=0.99)
    )
    assert st.decision is Decision.NEEDS_REVIEW
    assert st.confidence <= 0.4
    assert any("citation" in m.lower() for m in st.missing_evidence)


def test_limits_upgrade_admissible(chunks):
    st = state_with_evidence(chunks)
    DecisionAgent(ScriptedLLM({}))._apply(
        st,
        DecisionDraft(
            decision=Decision.ADMISSIBLE, confidence=0.9,
            applicable_limits=[ApplicableLimit(name="Room rent cap", description="1% of SI per day",
                                               chunk_ids=["p007-scope-01-abc123"])],
            citations=[DraftCitation(claim="Room rent capped at 1% of Sum Insured.",
                                     chunk_id="p007-scope-01-abc123")],
        ),
    )
    assert st.decision is Decision.ADMISSIBLE_WITH_LIMITS


def test_unresolved_dimension_caps_confidence(chunks):
    st = state_with_evidence(chunks)
    st.coverage = CoverageAssessment(unresolved_dimensions=["maternity"])
    DecisionAgent(ScriptedLLM({}))._apply(
        st,
        DecisionDraft(decision=Decision.ADMISSIBLE, confidence=0.98,
                      citations=[DraftCitation(claim="Covered.", chunk_id="p007-scope-01-abc123")]),
    )
    assert st.confidence <= 0.6


# --------------------------------------------------------------------------- #
def build_pipeline(retriever, responses) -> ClaimPipeline:
    llm = ScriptedLLM(responses)
    return ClaimPipeline(retriever=retriever, llm=llm)


ANALYSIS = {
    "case_summary": "test",
    "dimensions": [{"dimension": "exclusions", "why": "cosmetic surgery",
                    "queries": ["cosmetic plastic surgery exclusion liable"]}],
    "missing_fields": [],
}


def test_validation_failure_forces_needs_review(retriever):
    """The decision claims something the evidence does not say; after one
    revision attempt that still fails, the system must abstain."""
    responses = {
        "CaseAnalysis": ANALYSIS,
        "CoverageAssessment": {"findings": [], "limits": [], "missing_evidence": []},
        "DecisionDraft": {
            "decision": "NOT_ADMISSIBLE", "confidence": 0.9,
            "key_findings": [{"dimension": "exclusions",
                              "statement": "Dental implants are excluded for 24 months.",
                              "verdict": "EXCLUDES_COVERAGE",
                              "chunk_ids": ["p019-exclusions-03-ghi789"], "material": True}],
            "citations": [{"claim": "Dental implants are excluded for 24 months.",
                           "chunk_id": "p019-exclusions-03-ghi789"}],
        },
        # validator says: not supported
        "EntailmentBatch": lambda user: {
            "results": [{"index": i, "supported": False, "reason": "clause does not mention dental"}
                        for i in range(1, 6)]
        },
    }
    resp = build_pipeline(retriever, responses).run(ClaimCase(case_id="T-FAIL"))
    assert resp.decision is Decision.NEEDS_REVIEW
    assert resp.abstained is True
    assert resp.validation.status == "FAIL"
    assert any("Unsupported" in m for m in resp.missing_evidence)
    assert any(t.action == "revision_triggered" for t in resp.trace)


def test_supported_decision_passes(retriever):
    responses = {
        "CaseAnalysis": ANALYSIS,
        "CoverageAssessment": {
            "findings": [{"dimension": "exclusions",
                          "statement": "Cosmetic surgery is excluded unless due to accident or burns.",
                          "verdict": "EXCLUDES_COVERAGE",
                          "chunk_ids": ["p019-exclusions-03-ghi789"], "material": True}],
        },
        "DecisionDraft": {
            "decision": "NOT_ADMISSIBLE", "confidence": 0.88,
            "key_findings": [{"dimension": "exclusions",
                              "statement": "Cosmetic surgery is excluded unless due to accident or burns.",
                              "verdict": "EXCLUDES_COVERAGE",
                              "chunk_ids": ["p019-exclusions-03-ghi789"], "material": True}],
            "next_action": "Reject with clause reference.",
            "citations": [{"claim": "Cosmetic surgery is excluded unless due to accident or burns.",
                           "chunk_id": "p019-exclusions-03-ghi789"}],
        },
        "EntailmentBatch": lambda user: {
            "results": [{"index": i, "supported": True, "best_chunk_id": "p019-exclusions-03-ghi789",
                         "reason": "stated"} for i in range(1, 6)]
        },
    }
    resp = build_pipeline(retriever, responses).run(ClaimCase(case_id="T-OK"))
    assert resp.decision is Decision.NOT_ADMISSIBLE
    assert resp.validation.status == "PASS"
    assert resp.citations and resp.citations[0].page == 19
    assert not any(t.action == "revision_triggered" for t in resp.trace)


def test_agent_error_degrades_to_abstention(retriever):
    class Boom(ScriptedLLM):
        def complete_json(self, system, user, schema):
            raise RuntimeError("provider down")

    pipe = ClaimPipeline(retriever=retriever, llm=Boom({}))
    resp = pipe.run(ClaimCase(case_id="T-ERR"))
    assert resp.decision is Decision.NEEDS_REVIEW
    assert resp.confidence == 0.0
    assert any("Pipeline error" in m for m in resp.missing_evidence)


def test_trace_has_every_agent(retriever):
    responses = {"CaseAnalysis": ANALYSIS, "CoverageAssessment": {},
                 "DecisionDraft": {"decision": "NEEDS_REVIEW", "confidence": 0.2},
                 "EntailmentBatch": {"results": []}}
    resp = build_pipeline(retriever, responses).run(ClaimCase(case_id="T-TRACE"))
    agents = {t.agent for t in resp.trace}
    assert {"CaseAnalysisAgent", "PolicyEvidenceAgent", "CoverageExclusionAgent",
            "DecisionAgent"} <= agents
    assert all(t.elapsed_ms >= 0 for t in resp.trace)
