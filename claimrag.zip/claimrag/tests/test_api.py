import json

import pytest
from fastapi.testclient import TestClient

from app import api as api_module
from app.graph import ClaimPipeline
from tests.test_pipeline import ScriptedLLM


@pytest.fixture
def client(retriever, monkeypatch):
    llm = ScriptedLLM({
        "CaseAnalysis": {"case_summary": "t",
                         "dimensions": [{"dimension": "exclusions", "queries": ["cosmetic surgery exclusion"]}]},
        "CoverageAssessment": {},
        "DecisionDraft": {"decision": "NEEDS_REVIEW", "confidence": 0.2,
                          "missing_evidence": ["insufficient"]},
        "EntailmentBatch": {"results": []},
    })
    pipe = ClaimPipeline(retriever=retriever, llm=llm)
    monkeypatch.setattr(api_module, "_PIPELINE", pipe)
    monkeypatch.setattr(api_module, "pipeline", lambda: pipe)
    return TestClient(api_module.app)


def test_analyze_accepts_wrapped_and_bare(client):
    for payload in ({"case": {"case_id": "X-1"}}, {"case_id": "X-1"}):
        r = client.post("/analyze", json=payload)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["case_id"] == "X-1"
        assert body["decision"] in {
            "ADMISSIBLE", "ADMISSIBLE_WITH_LIMITS", "PARTIALLY_ADMISSIBLE",
            "NOT_ADMISSIBLE", "NEEDS_REVIEW",
        }
        assert "trace" in body and "validation" in body


def test_analyze_rejects_malformed(client):
    assert client.post("/analyze", json={}).status_code == 422
    assert client.post("/analyze", json={"case": "not-an-object"}).status_code == 422
    assert client.post("/analyze", json={"case": {}}).status_code == 422  # case_id required
    r = client.post("/analyze", content=b"{not json", headers={"Content-Type": "application/json"})
    assert r.status_code == 422


def test_extra_case_fields_survive(client):
    r = client.post("/analyze", json={"case": {"case_id": "X-2", "weird_attribute": {"a": [1, 2]}}})
    assert r.status_code == 200


def test_trace_exposes_no_chain_of_thought(client):
    body = client.post("/analyze", json={"case_id": "X-3"}).json()
    blob = json.dumps(body["trace"]).lower()
    for banned in ("let me think", "step 1:", "reasoning:", "i think that"):
        assert banned not in blob
