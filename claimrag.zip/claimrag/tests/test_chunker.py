from app.config import get_settings
from app.ingest import chunker
from app.ingest.chunker import Line


def fake_lines():
    body = 10.0
    return [
        Line("SCOPE OF COVER", 7, 14.0, True, 50),
        Line("The Company shall indemnify the medical expenses incurred for in-patient "
             "hospitalisation of the Insured Person, up to the Sum Insured.", 7, body, False, 70),
        Line("Waiting Periods", 11, 14.0, True, 40),
        Line("Pre-existing Diseases", 11, 12.0, True, 60),
        Line("Benefits payable for a pre-existing disease are excluded until forty-eight "
             "months of continuous coverage have elapsed since inception of the first policy.",
             11, body, False, 80),
        Line("12", 11, 8.0, False, 800),  # page-number noise
    ]


def test_sections_and_metadata(monkeypatch):
    monkeypatch.setattr(chunker, "read_lines", lambda p: fake_lines())
    chunks = chunker.chunk_pdf("ignored.pdf", get_settings())

    assert chunks, "chunker produced nothing"
    sections = {c.section for c in chunks}
    assert "SCOPE OF COVER" in sections
    assert "Pre-existing Diseases" in sections

    pe = next(c for c in chunks if c.section == "Pre-existing Diseases")
    assert pe.page == 11
    assert pe.section_path == ["Waiting Periods", "Pre-existing Diseases"], "heading hierarchy lost"
    assert pe.text.startswith("[Waiting Periods > Pre-existing Diseases]"), "heading not in chunk text"
    assert "forty-eight months" in pe.text


def test_no_cross_section_bleed(monkeypatch):
    monkeypatch.setattr(chunker, "read_lines", lambda p: fake_lines())
    chunks = chunker.chunk_pdf("ignored.pdf", get_settings())
    for c in chunks:
        assert not ("indemnify" in c.text and "pre-existing disease" in c.text), (
            "a chunk merged two different sections"
        )


def test_page_number_noise_dropped(monkeypatch):
    monkeypatch.setattr(chunker, "read_lines", lambda p: fake_lines())
    chunks = chunker.chunk_pdf("ignored.pdf", get_settings())
    assert all(c.text.strip().splitlines()[-1].strip() != "12" for c in chunks)


def test_chunk_ids_unique(monkeypatch):
    monkeypatch.setattr(chunker, "read_lines", lambda p: fake_lines())
    ids = [c.chunk_id for c in chunker.chunk_pdf("ignored.pdf", get_settings())]
    assert len(ids) == len(set(ids))
