import os

os.environ.setdefault("LLM_STUB", "1")
os.environ.setdefault("LLM_API_KEY", "")

import pytest

from app.models import Chunk, EvidenceItem


class FakeReranker:
    available = True

    def score(self, query, texts):
        q = set(query.lower().split())
        return [len(q & set(t.lower().split())) / (len(q) or 1) for t in texts]


class FakeRetriever:
    """Keyword retriever with the same interface as HybridRetriever."""

    def __init__(self, chunks):
        self.chunks = chunks
        self.by_id = {c.chunk_id: c for c in chunks}
        self.reranker = FakeReranker()
        self.stats = {"chunks": len(chunks), "pages": 1, "sections": 1,
                      "reranker_available": True}

    def retrieve(self, query, top_n=None):
        q = {w for w in query.lower().split() if len(w) > 3}
        scored = []
        for c in self.chunks:
            overlap = len(q & set(c.text.lower().split()))
            if overlap:
                scored.append((overlap, c))
        scored.sort(key=lambda x: -x[0])
        out = []
        for rank, (sc, c) in enumerate(scored[: (top_n or 5)], start=1):
            out.append(EvidenceItem(chunk_id=c.chunk_id, text=c.text, page=c.page,
                                    section=c.section, fusion_score=float(sc),
                                    rerank_score=float(sc), final_rank=rank, query=query))
        return out

    def retrieve_multi(self, queries, per_query=None, cap=24):
        merged = {}
        for q in queries:
            for it in self.retrieve(q, per_query):
                merged.setdefault(it.chunk_id, it)
        return list(merged.values())[:cap]


@pytest.fixture
def chunks():
    return [
        Chunk(chunk_id="p007-scope-01-abc123",
              text="[Scope of Cover] The Company shall indemnify medical expenses incurred "
                   "for in-patient hospitalisation of the Insured Person during the policy period.",
              page=7, page_end=7, section="Scope of Cover", section_path=["Scope of Cover"]),
        Chunk(chunk_id="p011-waiting-02-def456",
              text="[Waiting Periods > Pre-existing Diseases] Pre-existing diseases are excluded "
                   "until 48 months of continuous coverage have elapsed since inception.",
              page=11, page_end=11, section="Pre-existing Diseases",
              section_path=["Waiting Periods", "Pre-existing Diseases"]),
        Chunk(chunk_id="p019-exclusions-03-ghi789",
              text="[Permanent Exclusions] The Company shall not be liable for cosmetic or "
                   "plastic surgery unless necessitated by accident or burns.",
              page=19, page_end=19, section="Permanent Exclusions",
              section_path=["Permanent Exclusions"]),
    ]


@pytest.fixture
def retriever(chunks):
    return FakeRetriever(chunks)
