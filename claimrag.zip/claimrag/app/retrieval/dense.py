"""Dense semantic retrieval (bi-encoder + FAISS, numpy fallback)."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from app.models import Chunk

_MODEL_CACHE: dict[str, object] = {}


def get_encoder(name: str):
    if name not in _MODEL_CACHE:
        from sentence_transformers import SentenceTransformer

        _MODEL_CACHE[name] = SentenceTransformer(name)
    return _MODEL_CACHE[name]


class DenseIndex:
    """Cosine similarity over L2-normalised embeddings."""

    def __init__(self, model_name: str, embeddings: np.ndarray | None = None,
                 chunk_ids: list[str] | None = None):
        self.model_name = model_name
        self.embeddings = embeddings
        self.chunk_ids = chunk_ids or []
        self._faiss = None
        if embeddings is not None:
            self._build_faiss()

    # ---------------- build ----------------
    @classmethod
    def build(cls, chunks: list[Chunk], model_name: str, batch_size: int = 32) -> "DenseIndex":
        enc = get_encoder(model_name)
        texts = [c.text for c in chunks]
        emb = enc.encode(texts, batch_size=batch_size, normalize_embeddings=True,
                         show_progress_bar=True, convert_to_numpy=True)
        return cls(model_name, emb.astype("float32"), [c.chunk_id for c in chunks])

    def _build_faiss(self) -> None:
        try:
            import faiss

            index = faiss.IndexFlatIP(self.embeddings.shape[1])
            index.add(self.embeddings)
            self._faiss = index
        except Exception:  # numpy fallback is fine at this corpus size
            self._faiss = None

    # ---------------- persist ----------------
    def save(self, directory: Path) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        np.save(directory / "dense.npy", self.embeddings)
        (directory / "dense_ids.txt").write_text("\n".join(self.chunk_ids), encoding="utf-8")

    @classmethod
    def load(cls, directory: Path, model_name: str) -> "DenseIndex":
        emb = np.load(Path(directory) / "dense.npy")
        ids = (Path(directory) / "dense_ids.txt").read_text(encoding="utf-8").splitlines()
        return cls(model_name, emb, ids)

    # ---------------- query ----------------
    def search(self, query: str, top_k: int) -> list[tuple[str, float]]:
        enc = get_encoder(self.model_name)
        q = enc.encode(
            [f"Represent this sentence for searching relevant passages: {query}"],
            normalize_embeddings=True, convert_to_numpy=True,
        ).astype("float32")
        if self._faiss is not None:
            scores, idx = self._faiss.search(q, min(top_k, len(self.chunk_ids)))
            return [(self.chunk_ids[i], float(s)) for i, s in zip(idx[0], scores[0]) if i >= 0]
        sims = (self.embeddings @ q[0]).astype("float32")
        top = np.argsort(-sims)[:top_k]
        return [(self.chunk_ids[i], float(sims[i])) for i in top]
