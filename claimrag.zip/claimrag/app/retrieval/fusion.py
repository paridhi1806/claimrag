"""Reciprocal Rank Fusion.

RRF is used rather than score normalisation because BM25 scores and cosine
similarities live on incomparable scales and BM25's range shifts per query.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Fused:
    chunk_id: str
    score: float = 0.0
    dense_rank: int | None = None
    sparse_rank: int | None = None
    sources: set[str] = field(default_factory=set)


def reciprocal_rank_fusion(
    dense: list[tuple[str, float]],
    sparse: list[tuple[str, float]],
    k: int = 60,
) -> list[Fused]:
    table: dict[str, Fused] = {}
    for rank, (cid, _s) in enumerate(dense, start=1):
        f = table.setdefault(cid, Fused(cid))
        f.score += 1.0 / (k + rank)
        f.dense_rank = rank
        f.sources.add("dense")
    for rank, (cid, _s) in enumerate(sparse, start=1):
        f = table.setdefault(cid, Fused(cid))
        f.score += 1.0 / (k + rank)
        f.sparse_rank = rank
        f.sources.add("sparse")
    return sorted(table.values(), key=lambda f: -f.score)
