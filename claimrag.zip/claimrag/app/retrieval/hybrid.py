"""Hybrid retriever: dense + BM25 -> RRF -> cross-encoder rerank.

Exposes per-candidate retrieval metadata (dense rank, sparse rank, fusion score,
rerank score, final rank) so citation/evidence quality can be measured offline.
"""
from __future__ import annotations

import threading
from pathlib import Path

from app.config import Settings, get_settings
from app.ingest.chunker import load_chunks
from app.models import Chunk, EvidenceItem
from app.retrieval.dense import DenseIndex
from app.retrieval.fusion import reciprocal_rank_fusion
from app.retrieval.rerank import Reranker
from app.retrieval.sparse import SparseIndex

CHUNKS_FILE = "chunks.jsonl"


class IndexNotBuilt(RuntimeError):
    pass


class HybridRetriever:
    _instance: "HybridRetriever | None" = None
    _lock = threading.Lock()

    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        d = Path(self.settings.index_dir)
        if not (d / CHUNKS_FILE).exists():
            raise IndexNotBuilt(
                f"No index at {d}. Run:  python -m app.ingest.build_index --pdf <policy.pdf>"
            )
        self.chunks: list[Chunk] = load_chunks(d / CHUNKS_FILE)
        self.by_id: dict[str, Chunk] = {c.chunk_id: c for c in self.chunks}
        self.dense = DenseIndex.load(d, self.settings.embedding_model)
        self.sparse = SparseIndex.load(d)
        self.reranker = Reranker(self.settings.reranker_model)

    # Loaded once per process; models are heavy.
    @classmethod
    def instance(cls, settings: Settings | None = None) -> "HybridRetriever":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls(settings)
            return cls._instance

    @property
    def stats(self) -> dict:
        return {
            "chunks": len(self.chunks),
            "pages": max((c.page_end for c in self.chunks), default=0),
            "sections": len({c.section for c in self.chunks}),
            "embedding_model": self.settings.embedding_model,
            "reranker_model": self.settings.reranker_model,
            "reranker_available": self.reranker.available,
        }

    # ------------------------------------------------------------------ #
    def retrieve(self, query: str, top_n: int | None = None) -> list[EvidenceItem]:
        s = self.settings
        top_n = top_n or s.rerank_top_n
        dense_hits = self.dense.search(query, s.dense_top_k)
        sparse_hits = self.sparse.search(query, s.sparse_top_k)
        fused = reciprocal_rank_fusion(dense_hits, sparse_hits, k=s.rrf_k)
        candidates = fused[: max(s.dense_top_k, s.sparse_top_k)]
        if not candidates:
            return []

        texts = [self.by_id[f.chunk_id].text for f in candidates if f.chunk_id in self.by_id]
        candidates = [f for f in candidates if f.chunk_id in self.by_id]
        scores = self.reranker.score(query, texts)

        items: list[EvidenceItem] = []
        for f, sc in zip(candidates, scores):
            c = self.by_id[f.chunk_id]
            items.append(
                EvidenceItem(
                    chunk_id=c.chunk_id, text=c.text, page=c.page, section=c.section,
                    source=c.source, dense_rank=f.dense_rank, sparse_rank=f.sparse_rank,
                    fusion_score=round(f.score, 6),
                    rerank_score=round(sc, 4) if self.reranker.available else None,
                    query=query,
                )
            )
        if self.reranker.available:
            items.sort(key=lambda i: -(i.rerank_score or 0.0))
            items = [i for i in items if (i.rerank_score or 0.0) >= s.min_rerank_score]
        for rank, it in enumerate(items[:top_n], start=1):
            it.final_rank = rank
        return items[:top_n]

    def retrieve_multi(
        self, queries: list[str], per_query: int | None = None, cap: int = 24
    ) -> list[EvidenceItem]:
        """Run one retrieval per decision dimension and merge, keeping the best
        observation of each chunk. Multi-query is what lets a single decision
        combine evidence from several policy sections."""
        merged: dict[str, EvidenceItem] = {}
        for q in queries:
            for item in self.retrieve(q, per_query):
                prev = merged.get(item.chunk_id)
                if prev is None:
                    merged[item.chunk_id] = item
                else:
                    prev.query = f"{prev.query} | {q}"
                    if (item.rerank_score or -99) > (prev.rerank_score or -99):
                        prev.rerank_score = item.rerank_score
                    prev.fusion_score = max(prev.fusion_score, item.fusion_score)
        out = sorted(
            merged.values(),
            key=lambda i: (-(i.rerank_score if i.rerank_score is not None else 0.0), -i.fusion_score),
        )[:cap]
        for rank, it in enumerate(out, start=1):
            it.final_rank = rank
        return out
