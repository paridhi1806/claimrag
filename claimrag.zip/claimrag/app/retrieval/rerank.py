"""Cross-encoder reranking with a graceful, explicit fallback."""
from __future__ import annotations

_CACHE: dict[str, object] = {}


class Reranker:
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.available = True
        try:
            if model_name not in _CACHE:
                from sentence_transformers import CrossEncoder

                _CACHE[model_name] = CrossEncoder(model_name, max_length=512)
            self.model = _CACHE[model_name]
        except Exception:
            self.model = None
            self.available = False

    def score(self, query: str, texts: list[str]) -> list[float]:
        if not texts:
            return []
        if self.model is None:
            # fallback keeps fusion order; scores are flagged as unavailable
            return [0.0] * len(texts)
        pairs = [(query, t[:2000]) for t in texts]
        return [float(s) for s in self.model.predict(pairs)]
