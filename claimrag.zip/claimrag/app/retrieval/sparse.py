"""Sparse lexical retrieval (BM25).

Lexical matching matters here because policy decisions hinge on exact tokens
("36 months", "sub-limit", "co-payment", "pre-existing") that embeddings blur.
"""
from __future__ import annotations

import json
import pickle
import re
from pathlib import Path

from app.models import Chunk

TOKEN = re.compile(r"[a-z0-9]+(?:[.-][a-z0-9]+)*")
STOP = {
    "the", "a", "an", "of", "and", "or", "to", "in", "for", "on", "is", "are",
    "be", "as", "by", "with", "that", "this", "it", "at", "from", "any", "such",
}


def tokenize(text: str) -> list[str]:
    return [t for t in TOKEN.findall(text.lower()) if t not in STOP and len(t) > 1]


class SparseIndex:
    def __init__(self, bm25, chunk_ids: list[str]):
        self.bm25 = bm25
        self.chunk_ids = chunk_ids

    @classmethod
    def build(cls, chunks: list[Chunk]) -> "SparseIndex":
        from rank_bm25 import BM25Okapi

        corpus = [tokenize(f"{' '.join(c.section_path)} {c.text}") for c in chunks]
        return cls(BM25Okapi(corpus), [c.chunk_id for c in chunks])

    def save(self, directory: Path) -> None:
        directory.mkdir(parents=True, exist_ok=True)
        with (directory / "bm25.pkl").open("wb") as fh:
            pickle.dump(self.bm25, fh)
        (directory / "bm25_ids.json").write_text(json.dumps(self.chunk_ids), encoding="utf-8")

    @classmethod
    def load(cls, directory: Path) -> "SparseIndex":
        directory = Path(directory)
        with (directory / "bm25.pkl").open("rb") as fh:
            bm25 = pickle.load(fh)
        ids = json.loads((directory / "bm25_ids.json").read_text(encoding="utf-8"))
        return cls(bm25, ids)

    def search(self, query: str, top_k: int) -> list[tuple[str, float]]:
        scores = self.bm25.get_scores(tokenize(query))
        order = sorted(range(len(scores)), key=lambda i: -scores[i])[:top_k]
        return [(self.chunk_ids[i], float(scores[i])) for i in order if scores[i] > 0]
