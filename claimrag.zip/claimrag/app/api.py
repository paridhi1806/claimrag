"""FastAPI surface.

    POST /analyze   -> structured, evidence-backed decision for one claim case
    GET  /health    -> readiness (index + LLM configuration)
    GET  /cases     -> list bundled case ids (convenience for the UI)
    GET  /cases/{id}-> one bundled case
    GET  /index/stats
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.config import get_settings
from app.graph import ClaimPipeline
from app.llm.client import LLMClient
from app.models import AnalyzeRequest, AnalyzeResponse, ClaimCase
from app.retrieval.hybrid import HybridRetriever, IndexNotBuilt

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("claimrag.api")

app = FastAPI(
    title="ClaimRAG — evidence-grounded health-claim analysis",
    version="1.0.0",
    description="Hybrid-retrieval RAG + multi-agent workflow over a policy wording.",
)
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

_PIPELINE: ClaimPipeline | None = None
_INDEX_ERROR: str | None = None


def pipeline() -> ClaimPipeline:
    global _PIPELINE, _INDEX_ERROR
    if _PIPELINE is None:
        try:
            _PIPELINE = ClaimPipeline()
            _INDEX_ERROR = None
        except IndexNotBuilt as exc:
            _INDEX_ERROR = str(exc)
            raise HTTPException(status_code=503, detail=str(exc)) from exc
    return _PIPELINE


@app.on_event("startup")
def warm() -> None:
    try:
        pipeline()
        log.info("index + models loaded")
    except Exception as exc:  # health endpoint will report it
        log.warning("startup warm-up failed: %s", exc)


# --------------------------------------------------------------------------- #
@app.get("/health")
def health() -> JSONResponse:
    s = get_settings()
    llm_ready = LLMClient(s).ready
    try:
        stats = HybridRetriever.instance(s).stats
        index_ok = True
        detail = None
    except Exception as exc:
        stats, index_ok, detail = {}, False, str(exc)
    ok = index_ok and llm_ready
    return JSONResponse(
        status_code=200 if ok else 503,
        content={
            "status": "ok" if ok else "degraded",
            "index_ready": index_ok,
            "llm_configured": llm_ready,
            "llm_stub_mode": s.llm_stub,
            "model": s.llm_model,
            "index": stats,
            "detail": detail,
        },
    )


@app.post("/analyze", response_model=AnalyzeResponse)
def analyze(payload: dict = Body(...)) -> AnalyzeResponse:
    """Accepts either `{"case": {...}}` or a bare case object."""
    if not isinstance(payload, dict) or not payload:
        raise HTTPException(status_code=422, detail="Request body must be a non-empty JSON object.")
    raw = payload.get("case", payload)
    if not isinstance(raw, dict):
        raise HTTPException(status_code=422, detail="`case` must be a JSON object.")
    try:
        case = AnalyzeRequest(case=ClaimCase(**raw)).case
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail=json.loads(exc.json())) from exc
    except TypeError as exc:
        raise HTTPException(status_code=422, detail=f"Malformed case object: {exc}") from exc

    log.info("analyzing case_id=%s", case.case_id)
    return pipeline().run(case)


@app.get("/cases")
def list_cases() -> dict:
    s = get_settings()
    out: dict[str, list[str]] = {}
    for label, directory in (("public", s.public_cases_dir), ("custom", s.custom_cases_dir)):
        out[label] = sorted(p.stem for p in Path(directory).glob("*.json")) if Path(directory).exists() else []
    return out


@app.get("/cases/{case_id}")
def get_case(case_id: str) -> dict:
    s = get_settings()
    if not case_id.replace("-", "").replace("_", "").isalnum():
        raise HTTPException(status_code=400, detail="Invalid case id.")
    for directory in (s.public_cases_dir, s.custom_cases_dir):
        path = Path(directory) / f"{case_id}.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    raise HTTPException(status_code=404, detail=f"Case {case_id} not found.")


@app.get("/index/stats")
def index_stats() -> dict:
    try:
        return HybridRetriever.instance().stats
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.exception_handler(Exception)
def unhandled(_request, exc: Exception) -> JSONResponse:  # pragma: no cover
    log.exception("unhandled error")
    return JSONResponse(status_code=500, content={"error": type(exc).__name__, "detail": str(exc)[:300]})
