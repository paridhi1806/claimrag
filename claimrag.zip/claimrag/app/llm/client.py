"""Thin OpenAI-compatible chat client with strict JSON decoding.

Design notes
------------
* Provider-agnostic: any OpenAI-compatible `/chat/completions` endpoint works
  (OpenRouter, Groq, Together, DeepInfra, vLLM, Ollama). Configured by env only.
* The caller always passes a pydantic schema. The response is parsed, validated
  and — if it fails — repaired in exactly one extra turn that shows the model its
  own validation errors. If that also fails we raise, and the orchestrator
  degrades the case to NEEDS_REVIEW rather than inventing an answer.
* `LLM_STUB=1` swaps in a deterministic offline stub so the whole pipeline,
  the API and the tests can run without a key or network.
"""
from __future__ import annotations

import json
import re
import time
from typing import Type, TypeVar

import httpx
from pydantic import BaseModel, ValidationError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.config import Settings, get_settings

T = TypeVar("T", bound=BaseModel)

FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.S)


class LLMError(RuntimeError):
    pass


def _extract_json(text: str) -> str:
    m = FENCE.search(text)
    if m:
        text = m.group(1)
    text = text.strip()
    start = text.find("{")
    if start == -1:
        raise LLMError("model returned no JSON object")
    depth, in_str, esc = 0, False, False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    raise LLMError("unterminated JSON object in model output")


class LLMClient:
    def __init__(self, settings: Settings | None = None):
        self.s = settings or get_settings()
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self._client = httpx.Client(timeout=self.s.llm_timeout_s)

    # ------------------------------------------------------------------ #
    @property
    def ready(self) -> bool:
        return bool(self.s.llm_stub or self.s.llm_api_key)

    def close(self) -> None:
        self._client.close()

    @retry(
        reraise=True,
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        retry=retry_if_exception_type((httpx.HTTPError, LLMError)),
    )
    def _post(self, messages: list[dict], json_mode: bool = True) -> str:
        payload = {
            "model": self.s.llm_model,
            "messages": messages,
            "temperature": self.s.llm_temperature,
            "max_tokens": self.s.llm_max_tokens,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        r = self._client.post(
            f"{self.s.llm_base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {self.s.llm_api_key}",
                     "Content-Type": "application/json"},
            json=payload,
        )
        if r.status_code >= 500 or r.status_code == 429:
            raise LLMError(f"provider {r.status_code}: {r.text[:200]}")
        if r.status_code >= 400:
            raise LLMError(f"provider {r.status_code}: {r.text[:300]}")
        data = r.json()
        usage = data.get("usage") or {}
        self.calls += 1
        self.prompt_tokens += int(usage.get("prompt_tokens") or 0)
        self.completion_tokens += int(usage.get("completion_tokens") or 0)
        try:
            return data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError) as exc:
            raise LLMError(f"malformed provider response: {str(data)[:200]}") from exc

    # ------------------------------------------------------------------ #
    def complete_json(self, system: str, user: str, schema: Type[T]) -> tuple[T, int]:
        """Returns (validated object, elapsed_ms)."""
        t0 = time.perf_counter()
        if self.s.llm_stub:
            self.calls += 1
            return stub_response(schema, user), int((time.perf_counter() - t0) * 1000)

        if not self.s.llm_api_key:
            raise LLMError("LLM_API_KEY is not set (or set LLM_STUB=1)")

        sys_msg = (
            f"{system}\n\nReturn ONLY a single JSON object matching this schema. "
            f"No prose, no markdown, no explanation of your reasoning steps.\n"
            f"SCHEMA:\n{json.dumps(schema.model_json_schema())}"
        )
        messages = [{"role": "system", "content": sys_msg}, {"role": "user", "content": user}]
        raw = self._post(messages)
        try:
            return schema.model_validate_json(_extract_json(raw)), int(
                (time.perf_counter() - t0) * 1000
            )
        except (ValidationError, LLMError) as exc:
            messages += [
                {"role": "assistant", "content": raw[:4000]},
                {"role": "user",
                 "content": f"Your output failed validation:\n{str(exc)[:1200]}\n"
                            f"Return the corrected JSON object only."},
            ]
            raw2 = self._post(messages)
            obj = schema.model_validate_json(_extract_json(raw2))
            return obj, int((time.perf_counter() - t0) * 1000)


# ---------------------------------------------------------------------- #
# Offline stub
# ---------------------------------------------------------------------- #
def stub_response(schema: Type[T], user: str) -> T:
    """Deterministic, schema-valid output used when LLM_STUB=1.

    It is intentionally conservative: it produces an abstention rather than a
    confident decision, so nobody mistakes stub output for a real result.
    """
    name = schema.__name__
    if name == "CaseAnalysis":
        return schema.model_validate(
            {
                "case_summary": "[stub] offline analysis",
                "extracted_facts": {},
                "dimensions": [
                    {"dimension": "scope_of_cover", "why": "stub",
                     "queries": ["scope of cover hospitalisation expenses"]},
                    {"dimension": "waiting_periods", "why": "stub",
                     "queries": ["waiting period pre-existing disease"]},
                    {"dimension": "exclusions", "why": "stub",
                     "queries": ["permanent exclusions not covered"]},
                    {"dimension": "limits_and_sublimits", "why": "stub",
                     "queries": ["sub-limit room rent co-payment"]},
                ],
                "missing_fields": [],
                "irrelevant_attributes": [],
            }
        )
    if name == "CoverageAssessment":
        return schema.model_validate(
            {"findings": [], "limits": [], "exclusions_triggered": [],
             "waiting_period_effects": [],
             "missing_evidence": ["LLM running in offline stub mode"],
             "unresolved_dimensions": ["all"]}
        )
    if name == "DecisionDraft":
        return schema.model_validate(
            {"decision": "NEEDS_REVIEW", "confidence": 0.0,
             "key_findings": [], "applicable_limits": [],
             "missing_evidence": ["LLM running in offline stub mode"],
             "next_action": "Configure LLM_API_KEY and re-run.", "citations": []}
        )
    if name == "EntailmentBatch":
        return schema.model_validate({"results": []})
    return schema()  # schemas all carry defaults
