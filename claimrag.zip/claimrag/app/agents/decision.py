"""Agent 4 — Decision.

Combines specialist findings into the machine-readable decision. A deterministic
post-processor then enforces the invariants we are not willing to leave to a
language model (abstention, limits implying ADMISSIBLE_WITH_LIMITS, no citation
=> no confident decision).
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from app.agents.base import Agent, compact_json, format_evidence
from app.llm.client import LLMClient
from app.models import ApplicableLimit, CaseState, Citation, Decision, Finding

SYSTEM = """You are the deciding officer for a health-insurance claim.

Inputs: the case facts, the coverage specialist's structured findings, and the
retrieved policy clauses. Choose exactly one decision:

- ADMISSIBLE: supported by facts + policy, no material limit or deduction identified.
- ADMISSIBLE_WITH_LIMITS: admissible, but a limit, cap, sub-limit, co-payment,
  deductible or waiting-period effect changes the payable amount.
- PARTIALLY_ADMISSIBLE: only part of the claim is supported; name the non-payable part.
- NOT_ADMISSIBLE: the policy evidence supports rejection or an exclusion.
- NEEDS_REVIEW: a safe decision cannot be made because required evidence, a required
  document, or policy support is missing or uncertain.

Hard rules:
- Prefer NEEDS_REVIEW over a confident guess. Abstention is a correct answer.
- Every material statement in key_findings and every applicable limit must carry
  chunk_ids drawn verbatim from the supplied clauses.
- `citations` must restate each material claim together with the chunk_id that
  supports it. Do not cite a clause that does not mention the point.
- confidence is your calibrated probability (0-1) that the decision survives an
  independent review. Use <=0.4 when you abstain.
- next_action: the single concrete next step for a human reviewer.
- Output facts and conclusions only. Do not output your reasoning steps."""


class DraftCitation(BaseModel):
    claim: str
    chunk_id: str


class DecisionDraft(BaseModel):
    decision: Decision = Decision.NEEDS_REVIEW
    confidence: float = 0.0
    key_findings: list[Finding] = Field(default_factory=list)
    applicable_limits: list[ApplicableLimit] = Field(default_factory=list)
    missing_evidence: list[str] = Field(default_factory=list)
    next_action: str = ""
    citations: list[DraftCitation] = Field(default_factory=list)


class DecisionAgent(Agent):
    name = "DecisionAgent"

    def __init__(self, llm: LLMClient):
        self.llm = llm

    def run(self, state: CaseState, feedback: str | None = None) -> CaseState:
        cov = state.coverage.model_dump() if state.coverage else {}
        user = (
            f"CASE FACTS:\n{compact_json(state.analysis.model_dump() if state.analysis else {})}\n\n"
            f"COVERAGE SPECIALIST FINDINGS:\n{compact_json(cov)}\n\n"
            f"RETRIEVED POLICY CLAUSES:\n{format_evidence(state.evidence)}"
        )
        if feedback:
            user += (
                "\n\nVALIDATION FEEDBACK — a previous draft contained statements that the "
                "retrieved policy evidence does not support. Remove or weaken them, or "
                "abstain.\n" + feedback
            )
        label = "revise_decision" if feedback else "decide"
        with self.step(state, label, "combine findings into final decision") as rec:
            draft, _ms = self.llm.complete_json(SYSTEM, user, DecisionDraft)
            self._apply(state, draft)
            rec["results"] = len(state.citations)
            rec["detail"] = f"{state.decision.value} conf={state.confidence:.2f}"
        return state

    # ------------------------------------------------------------------ #
    def _apply(self, state: CaseState, draft: DecisionDraft) -> None:
        ev = state.evidence_by_id()
        state.key_findings = [
            f for f in draft.key_findings if f.statement.strip()
        ]
        for f in state.key_findings:
            f.chunk_ids = [c for c in f.chunk_ids if c in ev]
        state.applicable_limits = draft.applicable_limits
        for l in state.applicable_limits:
            l.chunk_ids = [c for c in l.chunk_ids if c in ev]

        seen: set[tuple[str, str]] = set()
        citations: list[Citation] = []
        for c in draft.citations:
            if c.chunk_id not in ev:
                continue
            key = (c.claim.strip().lower()[:120], c.chunk_id)
            if key in seen:
                continue
            seen.add(key)
            item = ev[c.chunk_id]
            citations.append(
                Citation(claim=c.claim.strip(), source=item.source, page=item.page,
                         section=item.section, chunk_id=c.chunk_id,
                         support_score=item.rerank_score)
            )
        state.citations = citations

        for m in draft.missing_evidence:
            if m not in state.missing_evidence:
                state.missing_evidence.append(m)

        decision = draft.decision
        confidence = max(0.0, min(1.0, float(draft.confidence)))
        next_action = draft.next_action.strip()

        # --- deterministic invariants -------------------------------------
        if not citations and decision != Decision.NEEDS_REVIEW:
            decision = Decision.NEEDS_REVIEW
            confidence = min(confidence, 0.3)
            state.missing_evidence.append(
                "No policy citation could be attached to the decision."
            )
            next_action = next_action or "Manual review: decision lacked policy citations."
        if decision == Decision.ADMISSIBLE and state.applicable_limits:
            decision = Decision.ADMISSIBLE_WITH_LIMITS
        if state.coverage and state.coverage.unresolved_dimensions and decision in (
            Decision.ADMISSIBLE, Decision.ADMISSIBLE_WITH_LIMITS
        ):
            confidence = min(confidence, 0.6)
        if decision == Decision.NEEDS_REVIEW:
            confidence = min(confidence, 0.4)
            if not state.missing_evidence:
                state.missing_evidence.append("Policy support insufficient for a safe decision.")

        state.decision = decision
        state.confidence = round(confidence, 2)
        state.next_action = next_action or (
            "Proceed with settlement per the stated limits."
            if decision in (Decision.ADMISSIBLE, Decision.ADMISSIBLE_WITH_LIMITS)
            else "Route to a human claims reviewer."
        )
