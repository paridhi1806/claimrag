"""Agent 2 — Policy Evidence.

Owns retrieval only. Runs one hybrid query set per decision dimension so that a
decision can combine clauses from several parts of a long document, and records
retrieval metadata for every candidate it returns.
"""
from __future__ import annotations

from app.agents.base import Agent
from app.models import CaseState
from app.retrieval.hybrid import HybridRetriever


class PolicyEvidenceAgent(Agent):
    name = "PolicyEvidenceAgent"

    def __init__(self, retriever: HybridRetriever, per_query: int | None = None, cap: int = 24):
        self.retriever = retriever
        self.per_query = per_query
        self.cap = cap

    def run(self, state: CaseState) -> CaseState:
        assert state.analysis is not None, "CaseAnalysisAgent must run first"
        for dim in state.analysis.dimensions:
            with self.step(state, "retrieve", f"dimension={dim.dimension}") as rec:
                items = self.retriever.retrieve_multi(dim.queries, self.per_query, cap=6)
                rec["results"] = len(items)
                dim.status = "resolved" if items else "unresolved"
                self._merge(state, items)

        with self.step(state, "rank_evidence", "merge + rerank across dimensions") as rec:
            state.evidence.sort(
                key=lambda e: (-(e.rerank_score if e.rerank_score is not None else 0.0),
                               -e.fusion_score)
            )
            state.evidence = state.evidence[: self.cap]
            for rank, e in enumerate(state.evidence, start=1):
                e.final_rank = rank
            rec["results"] = len(state.evidence)
            pages = sorted({e.page for e in state.evidence})
            rec["detail"] = f"pages: {pages[:12]}"
        return state

    @staticmethod
    def _merge(state: CaseState, items) -> None:
        index = {e.chunk_id: e for e in state.evidence}
        for it in items:
            prev = index.get(it.chunk_id)
            if prev is None:
                state.evidence.append(it)
                index[it.chunk_id] = it
            else:
                if (it.rerank_score or -99) > (prev.rerank_score or -99):
                    prev.rerank_score = it.rerank_score
                prev.fusion_score = max(prev.fusion_score, it.fusion_score)
                if it.query not in prev.query:
                    prev.query = f"{prev.query} | {it.query}"
