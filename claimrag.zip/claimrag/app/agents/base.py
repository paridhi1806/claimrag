"""Agent base class + trace instrumentation."""
from __future__ import annotations

import time
from contextlib import contextmanager

from app.models import CaseState, TraceStep


class Agent:
    """Agents read and write the shared typed `CaseState`. They never pass
    free-form text to each other, and they never emit chain-of-thought — only
    the concise actions recorded in the trace."""

    name: str = "Agent"

    def run(self, state: CaseState) -> CaseState:  # pragma: no cover - interface
        raise NotImplementedError

    @contextmanager
    def step(self, state: CaseState, action: str, detail: str = ""):
        t0 = time.perf_counter()
        rec = {"detail": detail, "results": None}
        try:
            yield rec
        finally:
            state.trace.append(
                TraceStep(
                    agent=self.name,
                    action=action,
                    detail=str(rec["detail"])[:300],
                    results=rec["results"],
                    elapsed_ms=int((time.perf_counter() - t0) * 1000),
                )
            )


def compact_json(obj, limit: int = 6000) -> str:
    import json

    s = json.dumps(obj, ensure_ascii=False, default=str)
    return s if len(s) <= limit else s[:limit] + " ...[truncated]"


def format_evidence(items, max_chars: int = 900) -> str:
    lines = []
    for e in items:
        body = e.text if len(e.text) <= max_chars else e.text[:max_chars] + "..."
        lines.append(
            f"[{e.chunk_id}] (page {e.page}, section: {e.section})\n{body}"
        )
    return "\n\n---\n\n".join(lines)
