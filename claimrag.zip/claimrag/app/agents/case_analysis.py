"""Agent 1 — Case Analysis.

Turns a raw claim JSON into: normalised facts, the decision dimensions that must
be investigated, and the fields that are missing. The dimensions become the
retrieval plan, which is why one claim produces many targeted queries instead of
one blob query.
"""
from __future__ import annotations

from app.agents.base import Agent, compact_json
from app.llm.client import LLMClient
from app.models import CaseAnalysis, CaseState, DecisionDimension

SYSTEM = """You are a health-insurance claim intake analyst.
You are given one synthetic claim case as JSON. You do NOT decide the claim.

Your job:
1. Summarise the case in one or two factual sentences.
2. Normalise the decisive facts (policy inception, claim/admission date, months of
   continuous cover, sum insured, diagnosis/procedure, hospital type, room category,
   itemised expenses, declared pre-existing conditions, documents available).
3. List the decision DIMENSIONS that must be investigated against the policy wording.
   Typical dimensions: scope_of_cover, hospitalisation_definition, day_care,
   waiting_period_initial, waiting_period_specific_disease, waiting_period_pre_existing,
   maternity, exclusions, room_rent_limit, sub_limits, co_payment, deductible,
   pre_post_hospitalisation, sum_insured_adequacy, network_vs_non_network,
   documentation_requirements. Only include dimensions the case actually raises.
4. For each dimension give 2-3 short retrieval queries phrased in the vocabulary of an
   Indian health-insurance policy wording (not the claimant's words).
5. List missing_fields: facts required to decide that the case does not contain.
6. List irrelevant_attributes: attributes present in the case that have no bearing on
   the policy decision (e.g. claimant occupation hobby, hospital star rating).

Do not state any policy rule. You have not seen the policy yet."""

# Safety net: these dimensions are always investigated even if the model omits them.
BASELINE = [
    DecisionDimension(
        dimension="scope_of_cover",
        why="baseline",
        queries=["scope of cover in-patient hospitalisation expenses covered",
                 "what is covered medical expenses hospitalisation"],
    ),
    DecisionDimension(
        dimension="waiting_periods",
        why="baseline",
        queries=["waiting period initial 30 days specific diseases",
                 "pre-existing disease waiting period months continuous coverage"],
    ),
    DecisionDimension(
        dimension="exclusions",
        why="baseline",
        queries=["permanent exclusions expenses not covered",
                 "general exclusions the company shall not be liable"],
    ),
    DecisionDimension(
        dimension="limits_and_sublimits",
        why="baseline",
        queries=["sub-limit per illness capping room rent ICU charges",
                 "co-payment deductible proportionate deduction"],
    ),
]


class CaseAnalysisAgent(Agent):
    name = "CaseAnalysisAgent"

    def __init__(self, llm: LLMClient):
        self.llm = llm

    def run(self, state: CaseState) -> CaseState:
        payload = compact_json(state.case.as_dict())
        with self.step(state, "analyze_case", "extract facts + build investigation plan") as rec:
            analysis, _ms = self.llm.complete_json(SYSTEM, f"CLAIM CASE:\n{payload}", CaseAnalysis)
            have = {d.dimension for d in analysis.dimensions}
            for base in BASELINE:
                if base.dimension not in have and not any(
                    base.dimension.split("_")[0] in h for h in have
                ):
                    analysis.dimensions.append(base.model_copy(deep=True))
            for d in analysis.dimensions:
                if not d.queries:
                    d.queries = [d.dimension.replace("_", " ")]
            state.analysis = analysis
            rec["results"] = len(analysis.dimensions)
            rec["detail"] = "dimensions: " + ", ".join(d.dimension for d in analysis.dimensions)
        if analysis.missing_fields:
            state.missing_evidence.extend(
                f"Case field missing: {f}" for f in analysis.missing_fields
            )
        return state
