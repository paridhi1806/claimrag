"""Agent 5 — Validation.

Independent evidence check, not a second opinion on the decision. For every
material statement it (a) re-retrieves policy text for that statement alone, so
the check does not inherit the decision agent's retrieval, and (b) asks the model
a narrow entailment question: does this specific clause state this?

FAIL sends the case back to the Decision agent once with the unsupported claims
attached. A second FAIL forces NEEDS_REVIEW — the system would rather abstain
than ship an unsupported conclusion.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from app.agents.base import Agent, format_evidence
from app.llm.client import LLMClient
from app.models import CaseState, UnsupportedClaim, ValidationResult
from app.retrieval.hybrid import HybridRetriever

SYSTEM = """You are a claims auditor verifying citations. For each numbered claim you are
given the policy clauses that were cited plus independently retrieved clauses.

Answer for each claim: is the claim's substance directly stated or unambiguously
entailed by at least one of the supplied clauses?

- `supported` = true ONLY if a supplied clause states it. Plausibility, industry norms
  and common sense are NOT support.
- Arithmetic applied to case facts (dates, amounts) counts as supported if the clause
  supplies the rule being applied.
- `best_chunk_id` = the clause that best supports it, or null.
- `reason` = one short sentence. No reasoning steps."""


class Entailment(BaseModel):
    index: int
    supported: bool = False
    best_chunk_id: str | None = None
    reason: str = ""


class EntailmentBatch(BaseModel):
    results: list[Entailment] = Field(default_factory=list)


class ValidationAgent(Agent):
    name = "ValidationAgent"

    def __init__(self, llm: LLMClient, retriever: HybridRetriever):
        self.llm = llm
        self.retriever = retriever

    def _material_claims(self, state: CaseState) -> list[tuple[str, list[str]]]:
        """Collect every statement the decision materially rests on, merging the
        chunk_ids attached to it from findings, limits and citations."""
        merged: dict[str, tuple[str, list[str]]] = {}

        def add(text: str, ids: list[str]) -> None:
            text = text.strip()
            if not text:
                return
            key = text.lower()[:160]
            if key in merged:
                prev_text, prev_ids = merged[key]
                merged[key] = (prev_text, list(dict.fromkeys(prev_ids + ids)))
            else:
                merged[key] = (text, list(dict.fromkeys(ids)))

        for f in state.key_findings:
            if f.material:
                add(f.statement, list(f.chunk_ids))
        for l in state.applicable_limits:
            add(f"{l.name}: {l.description}", list(l.chunk_ids))
        for c in state.citations:
            add(c.claim, [c.chunk_id])
        return list(merged.values())[:12]

    def run(self, state: CaseState) -> CaseState:
        claims = self._material_claims(state)
        if not claims:
            state.validation = ValidationResult(
                status="PASS", checked_claims=0,
                notes="No material claims to verify (abstention or empty decision).",
            )
            with self.step(state, "validate", "no material claims") as rec:
                rec["results"] = 0
            return state

        ev = state.evidence_by_id()
        blocks: list[str] = []
        structural: list[UnsupportedClaim] = []

        with self.step(state, "verify_claims", "independent re-retrieval per claim") as rec:
            for i, (text, ids) in enumerate(claims, start=1):
                cited = [ev[c] for c in ids if c in ev]
                if ids and not cited:
                    structural.append(
                        UnsupportedClaim(claim=text, reason="cited chunk_id not in retrieved evidence")
                    )
                fresh = self.retriever.retrieve(text, top_n=3)
                pool = {e.chunk_id: e for e in cited}
                for e in fresh:
                    pool.setdefault(e.chunk_id, e)
                blocks.append(f"CLAIM {i}: {text}\nCANDIDATE CLAUSES:\n{format_evidence(list(pool.values()), 700)}")
            rec["results"] = len(claims)
            rec["detail"] = f"{len(claims)} material claims re-checked"

        with self.step(state, "entailment_check", "clause-level support test") as rec:
            try:
                batch, _ms = self.llm.complete_json(
                    SYSTEM, "\n\n=====\n\n".join(blocks), EntailmentBatch
                )
            except Exception as exc:  # validation must never crash the pipeline
                state.errors.append(f"validation LLM error: {exc}")
                state.validation = ValidationResult(
                    status="FAIL", checked_claims=len(claims),
                    unsupported_claims=[UnsupportedClaim(claim="(all)", reason=f"validator unavailable: {exc}")],
                    notes="Validator could not run; treat as unverified.",
                )
                rec["results"] = 0
                return state

            by_index = {r.index: r for r in batch.results}
            unsupported = list(structural)
            for i, (text, _ids) in enumerate(claims, start=1):
                r = by_index.get(i)
                if r is None:
                    unsupported.append(UnsupportedClaim(claim=text, reason="validator returned no verdict"))
                elif not r.supported:
                    unsupported.append(UnsupportedClaim(claim=text, reason=r.reason or "not stated in policy evidence"))

            state.validation = ValidationResult(
                status="FAIL" if unsupported else "PASS",
                unsupported_claims=unsupported,
                checked_claims=len(claims),
                notes=f"{len(claims) - len(unsupported)}/{len(claims)} material claims evidence-backed.",
            )
            rec["results"] = len(claims) - len(unsupported)
            rec["detail"] = state.validation.status
        return state
