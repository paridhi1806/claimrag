"""Agent 3 — Coverage & Exclusion specialist.

Reads case facts + retrieved clauses and produces structured findings: what the
policy covers here, which waiting periods bite, which exclusions trigger, which
limits/sub-limits/co-payments apply, and what evidence is still missing.
It does NOT choose the final status — that separation keeps the decision agent
honest and makes each finding independently checkable.
"""
from __future__ import annotations

from app.agents.base import Agent, compact_json, format_evidence
from app.llm.client import LLMClient
from app.models import CaseState, CoverageAssessment

SYSTEM = """You are a policy coverage specialist for health-insurance claims.

You are given (a) the analysed case facts, (b) the investigation dimensions and
(c) numbered policy clauses retrieved from the authoritative policy wording.

Rules:
- The supplied clauses are your ONLY source of policy rules. Never use outside
  insurance or medical knowledge to assert what a policy says.
- Every finding must cite chunk_ids taken verbatim from the supplied clauses.
  Never invent a chunk_id. If no supplied clause supports a point, do not make the point.
- If the clauses needed for a dimension are absent or ambiguous, put that dimension in
  `unresolved_dimensions` and describe what is needed in `missing_evidence`.
- Compute waiting-period effects arithmetically from the case dates and the clause text
  (e.g. months of continuous coverage vs the stated waiting period) and show the numbers
  in the statement.
- `verdict` per finding: SUPPORTS_COVERAGE, LIMITS_COVERAGE, EXCLUDES_COVERAGE or
  INCONCLUSIVE.
- Mark `material=true` only for findings that can change the payable outcome.
- Statements must be short, factual, and checkable against the cited clause."""


class CoverageAgent(Agent):
    name = "CoverageExclusionAgent"

    def __init__(self, llm: LLMClient):
        self.llm = llm

    def run(self, state: CaseState) -> CaseState:
        assert state.analysis is not None
        valid_ids = {e.chunk_id for e in state.evidence}
        user = (
            f"CASE FACTS:\n{compact_json(state.analysis.model_dump())}\n\n"
            f"RAW CASE:\n{compact_json(state.case.as_dict(), 3000)}\n\n"
            f"RETRIEVED POLICY CLAUSES:\n{format_evidence(state.evidence)}"
        )
        with self.step(state, "assess_coverage", "waiting periods, exclusions, limits") as rec:
            assessment, _ms = self.llm.complete_json(SYSTEM, user, CoverageAssessment)
            dropped = self._strip_invalid_ids(assessment, valid_ids)
            state.coverage = assessment
            rec["results"] = len(assessment.findings)
            rec["detail"] = (
                f"{len(assessment.findings)} findings, {len(assessment.limits)} limits, "
                f"{len(assessment.exclusions_triggered)} exclusions"
                + (f", dropped {dropped} hallucinated chunk_ids" if dropped else "")
            )
        if assessment.missing_evidence:
            state.missing_evidence.extend(assessment.missing_evidence)
        return state

    @staticmethod
    def _strip_invalid_ids(assessment: CoverageAssessment, valid: set[str]) -> int:
        dropped = 0
        for f in assessment.findings:
            keep = [c for c in f.chunk_ids if c in valid]
            dropped += len(f.chunk_ids) - len(keep)
            f.chunk_ids = keep
            if not keep and f.verdict != "INCONCLUSIVE":
                f.verdict = "INCONCLUSIVE"
        for l in assessment.limits:
            keep = [c for c in l.chunk_ids if c in valid]
            dropped += len(l.chunk_ids) - len(keep)
            l.chunk_ids = keep
        return dropped
