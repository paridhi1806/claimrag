"""CLI: policy PDF -> chunks.jsonl + dense index + BM25 index.

    python -m app.ingest.build_index --pdf data/policy/policy.pdf
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from app.config import get_settings
from app.ingest.chunker import chunk_pdf, save_chunks
from app.retrieval.dense import DenseIndex
from app.retrieval.sparse import SparseIndex


def main() -> None:
    s = get_settings()
    ap = argparse.ArgumentParser(description="Build the policy index.")
    ap.add_argument("--pdf", default=str(s.policy_pdf))
    ap.add_argument("--out", default=str(s.index_dir))
    ap.add_argument("--dry-run", action="store_true", help="chunk only, no embeddings")
    args = ap.parse_args()

    pdf, out = Path(args.pdf), Path(args.out)
    if not pdf.exists():
        raise SystemExit(f"Policy PDF not found: {pdf}")

    print(f"[1/4] chunking {pdf.name} ...")
    chunks = chunk_pdf(pdf, s)
    lens = [c.char_len for c in chunks]
    print(f"      {len(chunks)} chunks | median {sorted(lens)[len(lens)//2]} chars "
          f"| {len({c.section for c in chunks})} distinct sections")
    top = Counter(c.section for c in chunks).most_common(8)
    for sec, n in top:
        print(f"        {n:>4}  {sec[:70]}")

    out.mkdir(parents=True, exist_ok=True)
    save_chunks(chunks, out / "chunks.jsonl")

    if args.dry_run:
        print("[dry-run] stopped after chunking.")
        return

    print("[2/4] building BM25 index ...")
    SparseIndex.build(chunks).save(out)

    print(f"[3/4] embedding with {s.embedding_model} ...")
    DenseIndex.build(chunks, s.embedding_model).save(out)

    meta = {
        "source": pdf.name,
        "chunks": len(chunks),
        "pages": max(c.page_end for c in chunks),
        "embedding_model": s.embedding_model,
        "chunk_target_chars": s.chunk_target_chars,
    }
    (out / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"[4/4] done -> {out}")


if __name__ == "__main__":
    main()
