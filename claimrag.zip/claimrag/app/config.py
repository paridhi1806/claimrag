"""Central configuration. Everything is overridable via environment variables."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ---- LLM ----
    llm_base_url: str = "https://openrouter.ai/api/v1"
    llm_api_key: str = ""
    llm_model: str = "meta-llama/llama-3.3-70b-instruct"
    llm_temperature: float = 0.0
    llm_max_tokens: int = 1600
    llm_timeout_s: float = 90.0
    llm_stub: bool = False

    # ---- paths ----
    policy_pdf: Path = ROOT / "data" / "policy" / "policy.pdf"
    index_dir: Path = ROOT / "data" / "index"
    public_cases_dir: Path = ROOT / "data" / "cases" / "public"
    custom_cases_dir: Path = ROOT / "evaluation" / "cases"

    # ---- retrieval ----
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    reranker_model: str = "BAAI/bge-reranker-base"
    dense_top_k: int = 20
    sparse_top_k: int = 20
    rrf_k: int = 60
    rerank_top_n: int = 8
    min_rerank_score: float = -6.0

    # ---- chunking ----
    chunk_target_chars: int = 1200
    chunk_max_chars: int = 1800
    chunk_overlap_chars: int = 150

    # ---- orchestration ----
    max_validation_retries: int = 1
    api_url: str = "http://localhost:8000"

    def resolve(self, p: Path) -> Path:
        p = Path(p)
        return p if p.is_absolute() else (ROOT / p)


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.policy_pdf = s.resolve(s.policy_pdf)
    s.index_dir = s.resolve(s.index_dir)
    s.public_cases_dir = s.resolve(s.public_cases_dir)
    s.custom_cases_dir = s.resolve(s.custom_cases_dir)
    return s
