"""Typed contracts shared by every agent, the API and the evaluation harness.

The `CaseState` object is the single structured message passed between agents;
agents never exchange free-form text.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


# --------------------------------------------------------------------------- #
# Policy index primitives
# --------------------------------------------------------------------------- #
class Chunk(BaseModel):
    chunk_id: str
    text: str
    page: int
    page_end: int
    section: str = "Unknown"
    section_path: list[str] = Field(default_factory=list)
    source: str = "policy.pdf"
    char_len: int = 0
    kind: Literal["prose", "table", "definition"] = "prose"


class EvidenceItem(BaseModel):
    """A retrieved chunk plus the scores that got it here (auditable retrieval)."""

    chunk_id: str
    text: str
    page: int
    section: str
    source: str = "policy.pdf"
    dense_rank: int | None = None
    sparse_rank: int | None = None
    fusion_score: float = 0.0
    rerank_score: float | None = None
    final_rank: int = 0
    query: str = ""

    def short(self, n: int = 700) -> str:
        return self.text if len(self.text) <= n else self.text[: n - 3] + "..."


class Citation(BaseModel):
    claim: str
    source: str = "policy.pdf"
    page: int
    section: str = "Unknown"
    chunk_id: str
    support_score: float | None = None


# --------------------------------------------------------------------------- #
# Case input
# --------------------------------------------------------------------------- #
class ClaimCase(BaseModel):
    """Deliberately permissive: public cases carry heterogeneous fields and we
    must not drop any of them. Only `case_id` is structurally required."""

    model_config = ConfigDict(extra="allow")

    case_id: str = Field(min_length=1, max_length=128)

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")


# --------------------------------------------------------------------------- #
# Agent outputs
# --------------------------------------------------------------------------- #
class DecisionDimension(BaseModel):
    """One question the case must be investigated along (drives retrieval)."""

    dimension: str
    why: str = ""
    queries: list[str] = Field(default_factory=list)
    status: Literal["open", "resolved", "unresolved"] = "open"


class CaseAnalysis(BaseModel):
    case_summary: str = ""
    extracted_facts: dict[str, Any] = Field(default_factory=dict)
    dimensions: list[DecisionDimension] = Field(default_factory=list)
    missing_fields: list[str] = Field(default_factory=list)
    irrelevant_attributes: list[str] = Field(default_factory=list)


class Finding(BaseModel):
    dimension: str = "general"
    statement: str
    verdict: Literal[
        "SUPPORTS_COVERAGE", "LIMITS_COVERAGE", "EXCLUDES_COVERAGE", "INCONCLUSIVE"
    ] = "INCONCLUSIVE"
    chunk_ids: list[str] = Field(default_factory=list)
    material: bool = True


class ApplicableLimit(BaseModel):
    name: str
    description: str
    basis: str = ""
    estimated_impact: str | None = None
    chunk_ids: list[str] = Field(default_factory=list)


class CoverageAssessment(BaseModel):
    findings: list[Finding] = Field(default_factory=list)
    limits: list[ApplicableLimit] = Field(default_factory=list)
    exclusions_triggered: list[str] = Field(default_factory=list)
    waiting_period_effects: list[str] = Field(default_factory=list)
    missing_evidence: list[str] = Field(default_factory=list)
    unresolved_dimensions: list[str] = Field(default_factory=list)


class Decision(str, Enum):
    ADMISSIBLE = "ADMISSIBLE"
    ADMISSIBLE_WITH_LIMITS = "ADMISSIBLE_WITH_LIMITS"
    PARTIALLY_ADMISSIBLE = "PARTIALLY_ADMISSIBLE"
    NOT_ADMISSIBLE = "NOT_ADMISSIBLE"
    NEEDS_REVIEW = "NEEDS_REVIEW"


class UnsupportedClaim(BaseModel):
    claim: str
    reason: str
    best_support_score: float | None = None


class ValidationResult(BaseModel):
    status: Literal["PASS", "FAIL"] = "PASS"
    unsupported_claims: list[UnsupportedClaim] = Field(default_factory=list)
    checked_claims: int = 0
    notes: str = ""


class TraceStep(BaseModel):
    agent: str
    action: str
    detail: str = ""
    results: int | None = None
    elapsed_ms: int = 0


# --------------------------------------------------------------------------- #
# Orchestration state + API response
# --------------------------------------------------------------------------- #
class CaseState(BaseModel):
    """The structured blackboard passed from agent to agent."""

    case: ClaimCase
    analysis: CaseAnalysis | None = None
    evidence: list[EvidenceItem] = Field(default_factory=list)
    coverage: CoverageAssessment | None = None
    decision: Decision | None = None
    confidence: float = 0.0
    key_findings: list[Finding] = Field(default_factory=list)
    applicable_limits: list[ApplicableLimit] = Field(default_factory=list)
    missing_evidence: list[str] = Field(default_factory=list)
    citations: list[Citation] = Field(default_factory=list)
    next_action: str = ""
    validation: ValidationResult = Field(default_factory=ValidationResult)
    trace: list[TraceStep] = Field(default_factory=list)
    revision_count: int = 0
    errors: list[str] = Field(default_factory=list)

    def evidence_by_id(self) -> dict[str, EvidenceItem]:
        return {e.chunk_id: e for e in self.evidence}


class AnalyzeResponse(BaseModel):
    case_id: str
    decision: Decision
    confidence: float
    abstained: bool = False
    key_findings: list[Finding] = Field(default_factory=list)
    applicable_limits: list[ApplicableLimit] = Field(default_factory=list)
    missing_evidence: list[str] = Field(default_factory=list)
    next_action: str = ""
    citations: list[Citation] = Field(default_factory=list)
    validation: ValidationResult = Field(default_factory=ValidationResult)
    retrieval: dict[str, Any] = Field(default_factory=dict)
    trace: list[TraceStep] = Field(default_factory=list)
    elapsed_ms: int = 0


class AnalyzeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    case: ClaimCase
