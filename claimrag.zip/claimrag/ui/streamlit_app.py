"""Reviewer-facing UI.

Calls the deployed API by default; falls back to running the pipeline in-process
if no API is reachable and the index is present locally.
"""
from __future__ import annotations

import json
import os
import time

import requests
import streamlit as st

API_URL = os.getenv("API_URL", "http://localhost:8000").rstrip("/")

DECISION_STYLE = {
    "ADMISSIBLE": ("#0f5132", "#d1e7dd", "✅"),
    "ADMISSIBLE_WITH_LIMITS": ("#664d03", "#fff3cd", "⚠️"),
    "PARTIALLY_ADMISSIBLE": ("#664d03", "#fff3cd", "◐"),
    "NOT_ADMISSIBLE": ("#842029", "#f8d7da", "⛔"),
    "NEEDS_REVIEW": ("#055160", "#cff4fc", "🛑"),
}

st.set_page_config(page_title="ClaimRAG", page_icon="🩺", layout="wide")


# --------------------------------------------------------------------------- #
def api_get(path: str, timeout: int = 10):
    r = requests.get(f"{API_URL}{path}", timeout=timeout)
    r.raise_for_status()
    return r.json()


def analyze(case: dict, timeout: int = 300) -> dict:
    r = requests.post(f"{API_URL}/analyze", json={"case": case}, timeout=timeout)
    if r.status_code >= 400:
        raise RuntimeError(f"API {r.status_code}: {r.text[:500]}")
    return r.json()


# --------------------------------------------------------------------------- #
st.title("🩺 ClaimRAG — evidence-grounded claim analysis")
st.caption(
    "Hybrid retrieval (dense + BM25 + cross-encoder rerank) over the policy wording, "
    "analysed by five specialised agents. Every material statement must carry a policy citation."
)

with st.sidebar:
    st.subheader("Backend")
    API_URL = st.text_input("API URL", API_URL).rstrip("/")
    try:
        health = api_get("/health")
        ok = health.get("status") == "ok"
        (st.success if ok else st.warning)(f"status: {health.get('status')}")
        idx = health.get("index", {})
        if idx:
            st.caption(
                f"{idx.get('chunks', '?')} chunks · {idx.get('pages', '?')} pages · "
                f"{idx.get('sections', '?')} sections"
            )
            st.caption(f"reranker: {'on' if idx.get('reranker_available') else 'FALLBACK (fusion order)'}")
        if health.get("llm_stub_mode"):
            st.warning("LLM is in STUB mode — outputs are placeholders.")
        st.caption(f"model: {health.get('model')}")
    except Exception as exc:
        st.error(f"Backend unreachable: {exc}")

    st.divider()
    st.subheader("Policy")
    st.caption(
        "CSC – Individual Health Insurance, Universal Sompo General Insurance "
        "(UIN UNIHLIP18004V011718). The supplied wording is the only source of policy rules."
    )

source = st.radio("Claim case source", ["Bundled case", "Upload JSON", "Paste JSON"], horizontal=True)
case: dict | None = None

if source == "Bundled case":
    try:
        groups = api_get("/cases")
        options = [f"{g}/{c}" for g, ids in groups.items() for c in ids]
    except Exception:
        options = []
    if options:
        choice = st.selectbox("Case", options)
        if choice:
            try:
                case = api_get(f"/cases/{choice.split('/', 1)[1]}")
            except Exception as exc:
                st.error(f"Could not load case: {exc}")
    else:
        st.info("No bundled cases found on the backend. Upload or paste a case instead.")
elif source == "Upload JSON":
    up = st.file_uploader("Claim case (.json)", type=["json"])
    if up:
        try:
            case = json.loads(up.read().decode("utf-8"))
        except json.JSONDecodeError as exc:
            st.error(f"Invalid JSON: {exc}")
else:
    text = st.text_area("Paste a claim case JSON", height=220, value="")
    if text.strip():
        try:
            case = json.loads(text)
        except json.JSONDecodeError as exc:
            st.error(f"Invalid JSON: {exc}")

if case:
    with st.expander("Input case", expanded=False):
        st.json(case)

run = st.button("Analyze claim", type="primary", disabled=case is None)

if run and case:
    t0 = time.perf_counter()
    with st.spinner("Retrieving policy evidence and running agents…"):
        try:
            result = analyze(case)
        except Exception as exc:
            st.error(str(exc))
            st.stop()
    st.session_state["result"] = result
    st.session_state["wall_ms"] = int((time.perf_counter() - t0) * 1000)

result = st.session_state.get("result")
if result:
    decision = result["decision"]
    fg, bg, icon = DECISION_STYLE.get(decision, ("#333", "#eee", "•"))
    st.markdown(
        f"""<div style="background:{bg};color:{fg};padding:16px 20px;border-radius:10px;
        font-size:22px;font-weight:700;margin:8px 0;">{icon} {decision}
        <span style="font-weight:400;font-size:15px;"> · confidence {result['confidence']:.2f}
        · {result['elapsed_ms']} ms · case {result['case_id']}</span></div>""",
        unsafe_allow_html=True,
    )

    if result.get("abstained"):
        st.warning(
            "**The system abstained.** A safe decision could not be made from the supplied "
            "policy wording and case facts. See *Missing evidence* below."
        )

    val = result.get("validation", {})
    cols = st.columns(4)
    cols[0].metric("Validation", val.get("status", "?"))
    cols[1].metric("Material claims checked", val.get("checked_claims", 0))
    cols[2].metric("Citations", len(result.get("citations", [])))
    cols[3].metric("Evidence chunks", result.get("retrieval", {}).get("evidence_count", 0))

    if val.get("status") == "FAIL":
        st.error("Validation FAILED — statements not supported by retrieved policy evidence:")
        for u in val.get("unsupported_claims", []):
            st.markdown(f"- **{u['claim']}** — _{u['reason']}_")

    tabs = st.tabs(["Findings & limits", "Policy evidence", "Execution trace", "Raw JSON"])

    with tabs[0]:
        left, right = st.columns(2)
        with left:
            st.subheader("Key findings")
            if not result.get("key_findings"):
                st.caption("No findings were recorded.")
            for f in result.get("key_findings", []):
                badge = {
                    "SUPPORTS_COVERAGE": "🟢", "LIMITS_COVERAGE": "🟡",
                    "EXCLUDES_COVERAGE": "🔴", "INCONCLUSIVE": "⚪",
                }.get(f["verdict"], "⚪")
                st.markdown(f"{badge} **{f['dimension']}** — {f['statement']}")
                if f.get("chunk_ids"):
                    st.caption("evidence: " + ", ".join(f["chunk_ids"]))
            st.subheader("Applicable limits / deductions")
            if not result.get("applicable_limits"):
                st.caption("None identified.")
            for l in result.get("applicable_limits", []):
                st.markdown(f"**{l['name']}** — {l['description']}")
                if l.get("estimated_impact"):
                    st.caption(f"impact: {l['estimated_impact']}")
                if l.get("chunk_ids"):
                    st.caption("evidence: " + ", ".join(l["chunk_ids"]))
        with right:
            st.subheader("Missing evidence")
            if not result.get("missing_evidence"):
                st.caption("Nothing flagged as missing.")
            for m in result.get("missing_evidence", []):
                st.markdown(f"- {m}")
            st.subheader("Next action")
            st.info(result.get("next_action") or "—")

    with tabs[1]:
        st.subheader("Citations")
        for c in result.get("citations", []):
            with st.expander(f"p.{c['page']} · {c['section']} · {c['chunk_id']}"):
                st.markdown(f"**Claim:** {c['claim']}")
                st.caption(f"source: {c['source']} · page {c['page']} · section: {c['section']}")
                if c.get("support_score") is not None:
                    st.caption(f"rerank score: {c['support_score']}")
        r = result.get("retrieval", {})
        st.caption(
            f"pages cited: {r.get('pages_cited')} · pages retrieved: {r.get('pages_retrieved')} · "
            f"LLM calls: {r.get('llm_calls')}"
        )
        st.subheader("Investigated dimensions")
        for d in r.get("dimensions", []):
            st.markdown(f"- **{d['dimension']}** ({d['status']}) — queries: {'; '.join(d['queries'])}")

    with tabs[2]:
        rows = [
            {
                "agent": t["agent"], "action": t["action"], "detail": t.get("detail", ""),
                "results": t.get("results"), "ms": t["elapsed_ms"],
            }
            for t in result.get("trace", [])
        ]
        st.dataframe(rows, use_container_width=True, hide_index=True)
        st.caption(
            "Trace shows agent actions, retrieval counts and timings only — no hidden "
            "chain-of-thought is exposed."
        )

    with tabs[3]:
        st.code(json.dumps(result, indent=2)[:200000], language="json")
        st.download_button(
            "Download result JSON",
            json.dumps(result, indent=2),
            file_name=f"{result['case_id']}_result.json",
            mime="application/json",
        )
